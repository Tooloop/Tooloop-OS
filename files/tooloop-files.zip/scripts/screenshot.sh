#!/bin/bash
scrot --silent "/assets/screenshots/$(date --rfc-3339=seconds).png"
