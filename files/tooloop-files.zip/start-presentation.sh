#!/bin/sh

# here comes everything, you want Tooloop to run
# don't forget to put an "&" at the end of each line, e.g. xeyes &

xeyes &
